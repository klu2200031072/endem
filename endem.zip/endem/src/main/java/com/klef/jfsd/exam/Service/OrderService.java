package com.klef.jfsd.exam.Service;

import com.klef.jfsd.exam.Model.Order;
import com.klef.jfsd.exam.Repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    public Order createOrder(Order order) {
        // Ensure to use the injected repository instance to save the order
        return orderRepository.save(order);
    }
}
