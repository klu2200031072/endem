package com.klef.jfsd.exam.Repository;

import com.klef.jfsd.exam.Model.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, Long> {
    // Custom queries (if needed) can be added here
}
